let users = {
  'name': {
    password: "artem20121101",
    name: 'name',
    key: 10102029337,
    email: 'gmail@outlock.RU'
  }
}



export { users }